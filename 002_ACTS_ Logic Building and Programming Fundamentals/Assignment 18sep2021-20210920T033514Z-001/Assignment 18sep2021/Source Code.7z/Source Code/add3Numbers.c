#include <stdio.h>

int main() {
    int first;
    int second;
    int third;
    int sum;
    int result;

    printf("Enter three integers to add: ");
    scanf("%d", &first);
    scanf("%d", &second);
    scanf("%d", &third);

    sum = first + second;
    result = sum + third;

    printf("Sum of three integers is: %d\n", result);

    return 0;
}
