#include <stdio.h>

int main() {
    int first, second, third, result;

    printf("Enter three integers to add: ");
    scanf("%d%d%d", &first, &second, &third);

    result = first + second + third;

    printf("Sum of three integers is: %d\n", result);

    return 0;
}
