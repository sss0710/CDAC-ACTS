#include <stdio.h>

int main() {
    unsigned int no;
    int count;

    printf("Enter a positive integer: ");
    scanf("%u", &no);

    count = 1;
    while (no >= 10) {
        no = no / 10;
        count = count + 1;
    }

    printf("Number has %d digit(s)\n", count);

    return 0;
}
