#include <stdio.h>

int main() {
    int n;
    int count;
    int term1;
    int term2;

    printf("How many terms to print: ");
    scanf("%d", &n);

    if (n == 1) {
        printf("1\n");
    } else if (n == 2) {
        printf("1 1\n");
    } else {
        printf("1 1 ");
        count = 2;
        term1 = 1;
        term2 = 1;

        while (count < n) {
            int nextTerm;

            nextTerm = term1 + term2;
            printf("%d ", nextTerm);
            term1 = term2;
            term2 = nextTerm;
            count = count + 1;
        }
        printf("\n");
    }

    return 0;
}
