#include <stdio.h>

int main() {
    int first;
    int second;
    int third;
    int max;
    int result;

    printf("Enter three integers to find maximum: ");
    scanf("%d", &first);
    scanf("%d", &second);
    scanf("%d", &third);

    if (first > second)
        max = first;
    else
        max = second;

    if (max > third)
        result = max;
    else
        result = third;

    printf("Maximum of three numbers is %d\n", result);

    return 0;
}
