#include <stdio.h>

int main() {
    int first, second, third, result;

    printf("Enter three integers to find maximum: ");
    scanf("%d%d%d", &first, &second, &third);

    if (first > second)
        result = first;
    else
        result = second;

    if (third > result)
        result = third;

    printf("Maximum of three numbers is %d\n", result);

    return 0;
}
