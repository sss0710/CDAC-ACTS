#include <stdio.h>

int main() {
    unsigned int reverse;
    unsigned int number;

    printf("Enter a positive integer: ");
    scanf("%u", &number);

    reverse = 0;
    while (number != 0) {
        int digit;

        digit = number % 10;
        reverse = reverse * 10;
        reverse = reverse + digit;
        number = number / 10;
    }

    printf("Reverse of number is %u\n", reverse);
    return 0;
}
