#include <stdio.h>

int main() {
    int n; // Uninitialized variables.
    int no; // Uninitialized variables.
    int sum = 0; // Initialization: When we assign a value to a variable at time of declaration.
                // Initialization happens only once for each variable.

    printf("Enter value for N: ");
    scanf("%d", &n);

    no = 1; // Assignment: We do via assignment operator, after variable is declared.
            // A variable can be assigned a value multiple times.
    while (no <= n) {
        sum = sum + no;
        no = no + 1; // Assignment.
    }

    printf("Sum of first N numbers is: %d\n", sum);

    return 0;
}
