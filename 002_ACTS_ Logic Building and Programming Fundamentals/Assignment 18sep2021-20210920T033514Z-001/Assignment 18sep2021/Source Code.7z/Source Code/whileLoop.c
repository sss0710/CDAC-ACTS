#include <stdio.h>

int main() {
    int n = 3;
    int no = 1;

    printf("First loop, with curly braces\n");
    while (no <= n) {
        no = no + 1;
        printf("1\n");
    }

    printf("Second loop, without curly braces\n");
    while (no <= n)
        no = no + 1;
        printf("1\n");

    return 0;
}
